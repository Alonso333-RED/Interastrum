from core.Spaceship import Spaceship
from core.Species import Species

def create_player(name: str):
    print("Elige como empezaras")