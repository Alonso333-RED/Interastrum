from enum import Enum

class Species(Enum):
    TERRANO = "Terrano"
    ORIONINO = "Orionino"
    LYRANO = "Lyrano"
    PEGASINO = "Pegasino"
