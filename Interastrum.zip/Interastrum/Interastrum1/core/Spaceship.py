class Spaceship:
    def __init__(self, 
                 integrity: int, max_speed: int, acceleration: float, deceleration: float, 
                 ):

        pass